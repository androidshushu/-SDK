package com.shiyue.game.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.shiyue.game.common.ApiListenerInfo;
import com.shiyue.game.common.ExitListener;
import com.shiyue.game.common.InitListener;
import com.shiyue.game.common.LoginMessageInfo;
import com.shiyue.game.common.RegisterMessage;
import com.shiyue.game.common.Syyx;
import com.shiyue.game.common.UserApiListenerInfo;
import com.shiyue.game.config.AppConfig;
import com.shiyue.game.pay.SjyxPaymentInfo;
import com.shiyue.game.user.LoginInfo;
import com.shiyue.game.R;

public class MainActivity extends Activity {
	private static final String TAG = "ShiYueSDK_MainActivity";
	// 初始化、登录、支付0.1元、账号小助手、退出
	private Button sdkInitButton, loginButton, payButton, ExtraDateButton,testBindphone, exitButton;
    //仙凡幻想包名com.shiyue.xfhx.sy微信登录参数
//    public static String wx_appid_demo = "wx5f44d324f9bc4175";
//    public static String wx_secret_demo = "1bf39cb9cd56fa8ea0818003178ef780";
	// 微信开放平台注册的参数，用于微信授权登录（本地Demo）
	public static String wx_appid_demo = "wxc87bf95d1eca3705";
	public static String wx_secret_demo = "5df57fe33adee26b74fd73a9cf065ada";
	// QQ互联平台注册的参数，用于QQ授权登录
	public static String qq_appid_demo = "101420001";
	public static String qq_appkey_demo = "a0033dedb7070a4aacd10343301d783f";
    public static InitListener initListener;
    /**
     * 请求用户给予悬浮窗的权限
     */
//    public void askForPermission() {
//        if (Build.VERSION.SDK_INT >= 23) {
//
//            if (!Settings.canDrawOverlays(this)) {
//                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
//                        Uri.parse("package:" + getPackageName()));
//                /** request permission via start activity for result */
//                startActivityForResult(intent, 1);
//            }
//
//        } else {
//        }
//    }
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_main);

		initView();	// 初始化控件
		Syyx.applicationInit(this);
		Syyx.setFloatBallPosition("left",78);
		Syyx.setUserListener(new UserApiListenerInfo() {
			@Override
			public void onLogout(Object obj) {

				super.onLogout(obj);

				LoginInfo loginInfo = new LoginInfo();
				//设置横竖屏
//				loginInfo.setOritation("portrait");	// 竖屏
				loginInfo.setOritation("landscape");	// 横屏
				Syyx.login(
						MainActivity.this, loginInfo, new ApiListenerInfo() {
					@Override
					public void onSuccess(Object obj) {
						if (obj != null) {
							LoginMessageInfo data = (LoginMessageInfo) obj;
							String result = data.getResult();
							String msg = data.getMessage();
							String userName = data.getUserName();
							String uid = AppConfig.Account_id;
							String timeStamp = data.getTimestamp();
							String token = data.getToken();

							Log.i("shiyues", "登录结果" + "result:" + result + "|msg:"
									+ msg + "|username:" + userName + "|uid:"
									+ uid + "|timeStamp:" + timeStamp
									 + "|token" + token);
						}
					}
				});
			}
		});

		// 进入就开始初始化
		oc.onClick(sdkInitButton);
	}
//	public void permission(){
//		if (Build.VERSION.SDK_INT >= 23) {
//			if(!Settings.canDrawOverlays(this)) {
//				Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
//				startActivity(intent);
//				return;
//			} else {
//				//Android6.0以上
////				if (mFloatView!=null && mFloatView.isShow()==false) {
////					mFloatView.show();
////				}
//			}
//		} else {
//			//Android6.0以下，不用动态声明权限
////			if (mFloatView!=null && mFloatView.isShow()==false) {
////				mFloatView.show();
////			}
//		}
//	}

	private void initView() {
		sdkInitButton = (Button) this.findViewById(R.id.button_sdkInit);
		loginButton = (Button) this.findViewById(R.id.button_login);
		payButton = (Button) this.findViewById(R.id.button_pay);
		ExtraDateButton = (Button) this.findViewById(R.id.button_ExtraDate);
		testBindphone = (Button) this.findViewById(R.id.button_test);
		exitButton = (Button) this.findViewById(R.id.button_exit);

		sdkInitButton.setOnClickListener(oc);
		payButton.setOnClickListener(oc);
		loginButton.setOnClickListener(oc);
		exitButton.setOnClickListener(oc);
		ExtraDateButton.setOnClickListener(oc);
		testBindphone.setOnClickListener(oc);
        initListener = new InitListener() {
            @Override
            public void initSuccess(String msg) {
                Log.d("ShiYueSDK","initSuccess");

            }
            @Override
            public void initFail(String msg) {
                Log.d("ShiYueSDK","initFail");
            }

            @Override
            public void realNameSuccess(int age) {
                Log.d("ShiYueSDK","realNameSuccess age="+age);
            }

            @Override
            public void realNameFail(int age) {
                Log.d("ShiYueSDK","realNameFail");

            }
        };

	}

	OnClickListener oc = new OnClickListener() {
		@Override
		public void onClick(View v) {
			if (v.equals(sdkInitButton)) {

                 /** v1.2.0版本以上不提供QQ，微信登录方式
                 * 注册微信，QQ的第三方登录参数调用是请传入对应的参数
                  * 第一个参数：appid
                  * 第二个参数：appkey
                 */
				Syyx.registerWXParameter(wx_appid_demo, wx_secret_demo);
				Syyx.registerQQParameter(qq_appid_demo, qq_appkey_demo);

				/**
				 * 初始化接口
				 * 第一个参数：this
				 * 第二个参数：getApplication()传入一个Application
				 * 第三个参数：true表示连接测试服，false表示连接正式服
				 * 第四个参数：InitListener:回调监听
                 * 返回结果信息：
                 * message:Success表示初始化成功；Fail：表示初始化失败
				 */
				Syyx.initInterface(MainActivity.this,getApplication(), true,initListener);

			} else if (v.equals(loginButton)) {
				// TODO: 2017/12/25 把传入的这个对象干掉，直接传入这个对象，横竖屏参数另外设置（或者通过这个值来控制横竖屏）
				LoginInfo loginInfo = new LoginInfo();
				loginInfo.setOritation("landscape");// 横屏
//                loginInfo.setOritation("portrait");// 竖屏
                /**
                 * SDK登录接口
                 * 登录回调参数
                 * message：Success：表示登录成功；Fail：表示登录失败
                 * username:用户名
                 * uid:用户id
                 * timeStamp:服务器时间
                 * sign:签名
                 */
				Syyx.login(MainActivity.this, loginInfo, new ApiListenerInfo() {
					@Override
					public void onSuccess(Object obj) {
						if (obj != null) {
							LoginMessageInfo data = (LoginMessageInfo) obj;
							String result = data.getResult();
							String msg = data.getMessage();
							String userName = data.getUserName();
							String uid = AppConfig.Account_id;
							String timeStamp = data.getTimestamp();
							String token = data.getToken();
							Log.i("登录结果：", "" + result + "|msg:"
									+ msg + "|username:" + userName + "|uid:"
									+ uid + "|timeStamp:" + timeStamp
									+ "|sign:" + "|token" + token);
						}
					}
					@Override
					public void onRegistFail(String msg) {
						Log.d(TAG,"onRegistFail  obj= " +msg);
						super.onRegistFail(msg);
					}
					@Override
					public void onRegistSucces(Object obj) {
						RegisterMessage registerMessage = (RegisterMessage) obj;
						Log.d(TAG,"onRegistSucces  result = " +registerMessage.getResult()+" method = "+registerMessage.getRegisterMethod());
						super.onRegistSucces(obj);
					}
				});
			} else if (v.equals(payButton)) {
				SjyxPaymentInfo payInfo = new SjyxPaymentInfo();
				payInfo.setExtraInfo("66$$44|ffff");// 额外信息透传参数：cText
				payInfo.setServerId("1");//服务器id
				payInfo.setAmount("0.01");//支付金额
				payInfo.setSubject("1");//商品描述
				payInfo.setNotifyUrl("http://s1.sygame.xy.shiyuegame.com/api/pf/sygame/callback.php");//支付回调地址，支付成功后用于通知服务器发送道具
				payInfo.setProductId("com.leniu.xlqy.100");//产品id
				payInfo.setRoleid("1");//角色id
//              payInfo.setAccountId(AppConfig.Account_id);//登录成功后sdk返回唯一uid

                /**
                 * 支付接口回调
                 * message:Success表示充值成功
                 */
				Syyx.payment(MainActivity.this, payInfo, new ApiListenerInfo() {

					@Override
					public void onSuccess(Object obj) {
						if (obj != null) {
							Log.i("充值结果：", "充值成功" + obj.toString());
						}
					}

				});
			} else if (v.equals(exitButton)) {
                /**
                 * 登出接口回调：
                 * 返回结果：
                 * code：0 退出成功
                 */
				Syyx.exit(MainActivity.this, new ExitListener() {
					@Override
					public void fail(String msg) {
					}

					@Override
					public void ExitSuccess(String msg) {

						if ("exit".equals(msg)) {
							AppConfig.IsLogin = 3;
							AppConfig.IfService = 3;
							System.exit(0);
						}
					}
				});
			}
			else if (v.equals(ExtraDateButton)) {
				// 角色数据上报（选接），上报完成不返回结果
//				HashMap<String, Object> params = new HashMap<String, Object>();
//				params.put("role_name","李佳哈dd");
//				params.put("role_id","4489278");
//				params.put("srv_id","3");
//				params.put("srv_name","审核服");
//				params.put("account","44953809");
//				params.put("role_level","156");
//				// type 301: 角色创建；       302：角色登录；         303：角色升级
//				Syyx.setExtData(MainActivity.this,params,302);
				//该接口后续需要同步到另两份SDK代码中
				Syyx.DisplayRealNameWindow(MainActivity.this,initListener );
//                Intent intent = new Intent();
//                intent.setClass(MainActivity.this, Sy_RealNameActivity.class);
//                startActivity(intent);

			}
 				else if (v.equals(testBindphone)){
			//支付配置接口
//			new InitPaySetting(MainActivity.this);
			//第三方支付充值成功信息上报接口
//			new ThirdChannelPay(MainActivity.this);
				//创建自己的账号体系
//                String logintype = AppConfig.logintype;
//				SeparateRegistration.getInstance().thirdquery(MainActivity.this,AppConfig.openid,logintype);
//                SeparateRegistration.getInstance().saveLoginType(MainActivity.this,logintype);
//                SeparateRegistration.getInstance().retrunLoginType(MainActivity.this);
//				YSDKPayOrderCreate.getInstance().PayOrderOnCreate(MainActivity.this,"60元宝","5689","46565","1","hdifhidhf","fffffffffff");

			}
		}
	};

    // 监听屏幕按钮点击事件
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Syyx.exit(MainActivity.this, new ExitListener() {
						@Override
						public void fail(String msg) {

						}
						@Override
						public void ExitSuccess(String msg) {

							if("exit".equals(msg)){
								System.exit(0);
							}
						}
					});

				}
			});
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		Syyx.onRestart(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
		Syyx.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		Syyx.onPause(this);
	}

	@Override
	protected void onStop() {
		super.onStop();
		Syyx.onstop(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Syyx.onDestroy(this);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		Syyx.onNewIntent(intent);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Syyx.onActivityResult(MainActivity.this, requestCode, resultCode, data);
	}
}
